PROCAST TECH — INDUSTRIAL GOLD / BLACK SINGLE-SCROLL WEBSITE
=============================================================
Design update:
- Overall background changed from flat white to blackish-gold industrial tones.
- Headings and navigation use an industrial condensed font treatment instead of Times/serif styling.
- Product cards, feature cards, stat cards and contact blocks use dark metallic panels with gold borders.
- Added subtle technical/industrial accents, dividers, highlights and depth.
- Cover image has NO white side overlay.
- Presentation headline remains separate HTML text below the cover.

Flow:
Home/Cover -> Presentation Text -> About -> Features -> 7 Products -> Contact

Phone: 9843058839
WhatsApp: 6374420244

Each product has an "Enquiry on WhatsApp" direct link with a product-specific message.
Founder: P. Rajendran
Established: 1999
